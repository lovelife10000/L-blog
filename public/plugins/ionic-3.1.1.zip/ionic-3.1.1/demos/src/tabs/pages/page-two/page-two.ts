import { Component } from '@angular/core';

@Component({
  template: '<div>johnny utah</div>',
  selector: 'tab-page'
})
export class PageTwo {}
