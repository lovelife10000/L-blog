module.exports = {
  name: 'dump',
  process: function(obj) {
    console.log(obj);
  }
};