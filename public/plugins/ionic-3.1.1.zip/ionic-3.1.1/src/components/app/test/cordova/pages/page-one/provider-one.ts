import { Injectable } from '@angular/core';

@Injectable()
export class SomeData {
  constructor() {}

  getData() {
    return 'SomeData';
  }
}
