import { Injectable } from '@angular/core';

@Injectable()
export class OtherData {
  constructor() {}

  getData() {
    return 'OtherData';
  }
}
