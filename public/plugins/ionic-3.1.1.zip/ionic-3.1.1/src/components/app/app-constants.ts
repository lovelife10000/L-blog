export const PORTAL_DEFAULT = 1;
export const PORTAL_MODAL = 2;
export const PORTAL_LOADING = 3;
export const PORTAL_TOAST = 4;
